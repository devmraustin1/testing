-- Database: `product_review_db`
--
-- This script creates the database schema and populates it with initial data.
-- It's designed to be run once when setting up your MySQL database on Hostinger.

-- --- START DATABASE CREATION ---
CREATE DATABASE IF NOT EXISTS `product_review_db`;
USE `product_review_db`;
-- --- END DATABASE CREATION ---


-- --- START TABLE CREATION ---

-- ➡️ users Table: Stores user authentication and profile information.
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL, -- IMPORTANT: In a real app, hash passwords! (e.g., using PHP's password_hash)
  `phone_number` VARCHAR(20) NULL,
  `gender` ENUM('Male', 'Female', 'Other') NULL,
  `join_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `balance` DECIMAL(10, 2) DEFAULT 0.00,
  `vip_level` INT DEFAULT 0,
  `is_admin` BOOLEAN DEFAULT FALSE -- '1' for admin, '0' for regular user
);

-- 📦 products Table: Information about products available for review.
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `price` DECIMAL(10, 2) NOT NULL,
  `commission_rate` DECIMAL(5, 2) NOT NULL, -- e.g., 0.05 for 5%
  `image_url` VARCHAR(255) NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `min_vip_level` INT DEFAULT 1 -- Minimum VIP level required to access this product
);

-- 💰 transactions Table: Records all financial activities (commissions, deposits, withdrawals).
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `product_id` INT NULL, -- Link to product if it's a commission
  `type` ENUM('commission', 'deposit', 'withdrawal', 'admin_adjustment') NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `description` TEXT NULL,
  `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `status` ENUM('pending', 'completed', 'rejected') DEFAULT 'pending', -- Status for deposits/withdrawals
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`)
);

-- 📝 reviews Table: Stores actual product reviews submitted by users.
CREATE TABLE IF NOT EXISTS `reviews` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    `rating` INT CHECK (rating >= 1 AND rating <= 5),
    `review_text` TEXT NULL,
    `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`),
    UNIQUE (`user_id`, `product_id`) -- Ensures a user can only review a product once
);

-- 📈 daily_reports Table: For aggregated data for the admin backend (e.g., daily totals).
CREATE TABLE IF NOT EXISTS `daily_reports` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `report_date` DATE NOT NULL UNIQUE,
    `total_commissions` DECIMAL(10, 2) DEFAULT 0.00,
    `total_orders` INT DEFAULT 0,
    `new_users` INT DEFAULT 0,
    `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 🎁 invite_codes Table: Manages invite codes for user registration bonuses.
CREATE TABLE IF NOT EXISTS `invite_codes` (
  `code` VARCHAR(50) PRIMARY KEY,
  `created_by_user_id` INT NULL, -- Admin or user who generated it
  `max_uses` INT DEFAULT 0, -- 0 for unlimited uses
  `current_uses` INT DEFAULT 0,
  `bonus_amount` DECIMAL(10, 2) DEFAULT 0.00, -- Bonus for new user signing up with this code
  `status` ENUM('active', 'inactive', 'expired') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`id`)
);

-- ⚙️ system_settings Table: Stores global configurable parameters like withdrawal fees.
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 💎 vip_plans Table: Stores VIP level details (e.g., commission rates, task limits per level).
CREATE TABLE IF NOT EXISTS `vip_plans` (
  `level` INT PRIMARY KEY,
  `level_name` VARCHAR(50) NOT NULL,
  `min_deposit_range` DECIMAL(10, 2) NOT NULL,
  `max_deposit_range` DECIMAL(10, 2) NOT NULL,
  `commission_rate` DECIMAL(5, 2) NOT NULL, -- e.g., 0.005 for 0.5%
  `tasks_per_group` INT DEFAULT 40,
  `daily_task_limit` INT DEFAULT 120,
  `lucky_order_reward` DECIMAL(5, 2) DEFAULT 0.00, -- e.g., 0.05 for 5%
  `deposit_return_event` BOOLEAN DEFAULT FALSE
);
-- --- END TABLE CREATION ---


-- --- START INITIAL DATA INSERTION ---

-- Add some dummy users for testing (admin and regular user)
INSERT IGNORE INTO `users` (`id`, `username`, `password`, `phone_number`, `gender`, `balance`, `vip_level`, `is_admin`) VALUES
(1, 'adminuser', 'admin', NULL, NULL, 1000.00, 5, TRUE),
(2, 'testuser', 'testpass', '123-456-7890', 'Male', 50.00, 1, FALSE);

-- Add some dummy products for review tasks
INSERT IGNORE INTO `products` (`id`, `name`, `description`, `price`, `commission_rate`, `image_url`, `min_vip_level`) VALUES
(1, 'Luxury Watch', 'A beautiful timepiece with automatic movement.', 250.00, 0.05, 'https://placehold.co/400x300/0f172a/e2e8f0?text=Watch', 1),
(2, 'Ergonomic Mouse', 'Comfortable and precise for long work sessions.', 45.00, 0.10, 'https://placehold.co/400x300/0f172a/e2e8f0?text=Mouse', 1),
(3, 'Noise-Cancelling Headphones', 'Immerse yourself in pure audio bliss.', 180.00, 0.07, 'https://placehold.co/400x300/0f172a/e2e8f0?text=Headphones', 2);

-- Initial System Settings
INSERT IGNORE INTO `system_settings` (`setting_key`, `setting_value`, `description`) VALUES
('withdraw_fee_percent', '1.0', 'Percentage fee for withdrawals.'),
('min_deposit_amount', '50.00', 'Minimum amount allowed for a deposit.'),
('min_withdrawal_amount', '10.00', 'Minimum amount allowed for a withdrawal.'),
('site_status', 'online', 'Current status of the website (online, maintenance, offline).');

-- Add dummy VIP plan data
INSERT IGNORE INTO `vip_plans` (`level`, `level_name`, `min_deposit_range`, `max_deposit_range`, `commission_rate`, `tasks_per_group`, `daily_task_limit`, `lucky_order_reward`, `deposit_return_event`) VALUES
(1, 'VIP 1', 50.00, 999.00, 0.005, 40, 120, 0.05, TRUE),
(2, 'VIP 2', 999.01, 4999.00, 0.007, 40, 120, 0.07, TRUE),
(3, 'VIP 3', 5000.00, 14999.00, 0.010, 40, 120, 0.10, TRUE),
(4, 'VIP 4', 15000.00, 999999.00, 0.015, 40, 120, 0.15, FALSE);

-- --- END INITIAL DATA INSERTION ---